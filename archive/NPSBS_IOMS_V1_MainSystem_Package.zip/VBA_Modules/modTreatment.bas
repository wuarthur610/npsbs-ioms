Attribute VB_Name = "modTreatment"
Option Explicit

' 對應 M5_VBA_Map: modTreatment — Treatment record and session logic
' 這是 frmDailyTreatment 送出資料時呼叫的主要進入點，完整實作
' M5_03_Operation_Flow 的 Step 3~8 與 M5_03_VBA_Workflow 的 WF01。
'
' Treatment_Record 欄位順序（供對照）:
' A TreatmentRecordID | B CustomerName | C CustomerID | D TreatmentDate | E TherapistID |
' F StartTime | G EndTime | H TimeAdjustedFlag | I SessionCount | J AdjustedSessions |
' K SessionAdjustedFlag | L TreatmentType | M BookingType | N CardID | O CardUsageStatus |
' P ShortageSessions | Q ShortageResolution | R ShortageStatus | S Notes | T CreatedBy | U CreatedAt

Public Function CalculateSessions(ByVal StartTime As Date, ByVal EndTime As Date, _
                                   ByVal AdjustedSessions As Variant) As Double
    CalculateSessions = modIOMS_Core.CalculateSessionCount(StartTime, EndTime, AdjustedSessions)
End Function

Public Function ApplyAdjustedSessions(ByVal AdjustedSessions As Variant) As Boolean
    ApplyAdjustedSessions = modIOMS_Core.SessionAdjustedFlag(AdjustedSessions)
End Function

' 主流程：建立一筆調理紀錄（含卡片扣堂／不足處理／稽核紀錄）
' 回傳新產生的 TreatmentRecordID
'
' ShortageResolution 只有在系統判斷 CardUsageStatus = "Insufficient" 時才需要提供，
' 由 frmDailyTreatment 在偵測到不足時才顯示對應下拉選單並再次呼叫本函式一次完成。
Public Function CreateTreatmentTransaction(ByVal CustomerName As String, ByVal CustomerID As String, _
        ByVal TreatmentDate As Date, ByVal TherapistID As String, _
        ByVal StartTime As Date, ByVal EndTime As Date, ByVal TimeAdjustedFlag As Boolean, _
        ByVal AdjustedSessions As Variant, ByVal TreatmentType As String, ByVal BookingType As String, _
        Optional ByVal ShortageResolution As String = "", Optional ByVal Notes As String = "") As String

    On Error GoTo ErrHandler

    Dim ws As Worksheet, r As Long, newID As String
    Dim sessionCount As Double, sessionAdjustedFlag As Boolean
    Dim cardID As String, cardUsageStatus As String
    Dim beforeSessions As Double, usedSessions As Double, shortageSessions As Double, afterSessions As Double
    Dim shortageStatus As String

    ' --- 1. 驗證必填欄位（依 UI_Daily_Treatment）---
    modValidation.RequireField CustomerName, "客戶姓名為必填。"
    modValidation.RequireField CStr(TreatmentDate), "調理日期為必填。"
    modValidation.RequireField TherapistID, "調理師為必填。"
    modValidation.RequireField TreatmentType, "調理項目為必填。"
    modValidation.RequireField BookingType, "預約類型為必填。"

    If Trim$(CustomerID) = "" Then
        Err.Raise vbObjectError + 2601, , "CustomerID 尚未帶出，請先確認客戶姓名。"
    End If

    ' --- 2. 計算堂數 ---
    sessionCount = CalculateSessions(StartTime, EndTime, AdjustedSessions)
    sessionAdjustedFlag = ApplyAdjustedSessions(AdjustedSessions)

    ' --- 3. 尋找當日有效套卡（只找 PurchaseDate <= TreatmentDate 且 Active）---
    cardID = modCard.FindUsableCard(CustomerID, TreatmentDate)

    If cardID = "" Then
        cardUsageStatus = "NoCard"
        usedSessions = 0
        shortageSessions = 0
        shortageStatus = "NotApplicable"
    Else
        beforeSessions = modCard.GetCardRemainingSessions(cardID)
        modCardDeduction.DeductSessions beforeSessions, sessionCount, usedSessions, shortageSessions
        afterSessions = Application.Max(beforeSessions - usedSessions, 0)

        If shortageSessions > 0 Then
            cardUsageStatus = "Insufficient"
            ' 不足時必須由店長選擇處理方式才能結案
            If Not modShortage.ValidShortageResolution(ShortageResolution) Then
                Err.Raise vbObjectError + 2602, , _
                    "套卡堂數不足，請選擇：收取減少堂數費用／直接減免／暫時保留至下次購買再扣堂數。"
            End If
            If ShortageResolution = modShortage.RES_PENDING Then
                shortageStatus = "Pending"
            Else
                shortageStatus = "Resolved"
            End If
        Else
            cardUsageStatus = "AutoDeducted"
            shortageStatus = "NotApplicable"
        End If
    End If

    ' --- 4. 產生 TreatmentRecordID 並寫入 Treatment_Record（原始紀錄，之後不可覆寫）---
    Set ws = ThisWorkbook.Worksheets("Treatment_Record")
    r = ws.Cells(ws.Rows.Count, 1).End(xlUp).Row + 1
    newID = "TR-" & Format(TreatmentDate, "yyyymmdd") & "-" & Format(r - 1, "0000")

    ws.Cells(r, 1).Value = newID
    ws.Cells(r, 2).Value = CustomerName
    ws.Cells(r, 3).Value = CustomerID
    ws.Cells(r, 4).Value = TreatmentDate
    ws.Cells(r, 5).Value = TherapistID
    ws.Cells(r, 6).Value = StartTime
    ws.Cells(r, 7).Value = EndTime
    ws.Cells(r, 8).Value = TimeAdjustedFlag
    ws.Cells(r, 9).Value = sessionCount
    ws.Cells(r, 10).Value = AdjustedSessions
    ws.Cells(r, 11).Value = sessionAdjustedFlag
    ws.Cells(r, 12).Value = TreatmentType
    ws.Cells(r, 13).Value = BookingType
    ws.Cells(r, 14).Value = cardID
    ws.Cells(r, 15).Value = cardUsageStatus
    ws.Cells(r, 16).Value = shortageSessions
    ws.Cells(r, 17).Value = ShortageResolution
    ws.Cells(r, 18).Value = shortageStatus
    ws.Cells(r, 19).Value = Notes
    ws.Cells(r, 20).Value = Environ$("Username")
    ws.Cells(r, 21).Value = Now

    ' --- 5. 若有扣堂，寫入 Card_Usage_Detail 並回寫 Card_Master 餘額 ---
    If cardID <> "" And usedSessions > 0 Then
        modCardUsage.CreateUsageDetail newID, cardID, TreatmentDate, beforeSessions, usedSessions, Notes
        modCard.ApplyDeduction cardID, usedSessions, afterSessions
    End If

    ' --- 6. 若時間被人工修正，或有堂數調整，額外寫入 Audit_Log ---
    If TimeAdjustedFlag Then
        modAudit.WriteAuditLog "Update", "Treatment_Record", newID, "StartTime/EndTime", "", _
            Format(StartTime, "hh:mm") & "-" & Format(EndTime, "hh:mm"), "人工修正調理時間"
    End If
    If sessionAdjustedFlag Then
        modAudit.WriteAuditLog "Update", "Treatment_Record", newID, "SessionCount", "", _
            CStr(sessionCount), "人工調整堂數"
    End If

    modAudit.WriteAuditLog "Create", "Treatment_Record", newID, "TreatmentRecordID", "", newID

    CreateTreatmentTransaction = newID
    Exit Function

ErrHandler:
    modErrorHandler.IOMSError "modTreatment.CreateTreatmentTransaction", Err.Number, Err.Description
    CreateTreatmentTransaction = ""
End Function

' 日後補扣 PendingNextCard：只有購買新套卡後才可呼叫。
' 不修改原始 Treatment_Record，只新增一筆 Card_Usage_Detail，並把 ShortageStatus 更新為 Resolved。
Public Sub SettlePendingShortage(ByVal OriginalTreatmentRecordID As String, ByVal NewCardID As String, _
                                  ByVal Sessions As Double)
    Dim ws As Worksheet, r As Long, lastRow As Long
    Dim beforeSessions As Double, usedSessions As Double, shortageSessions As Double

    beforeSessions = modCard.GetCardRemainingSessions(NewCardID)
    modCardDeduction.DeductSessions beforeSessions, Sessions, usedSessions, shortageSessions

    modCardUsage.CreateUsageDetail OriginalTreatmentRecordID, NewCardID, Date, beforeSessions, _
        usedSessions, "PendingNextCard 補扣"
    modCard.ApplyDeduction NewCardID, usedSessions, Application.Max(beforeSessions - usedSessions, 0)

    ' 更新原 Treatment_Record 的 ShortageStatus 為 Resolved（唯一允許事後更新的欄位）
    Set ws = ThisWorkbook.Worksheets("Treatment_Record")
    lastRow = ws.Cells(ws.Rows.Count, 1).End(xlUp).Row
    For r = 2 To lastRow
        If CStr(ws.Cells(r, 1).Value) = OriginalTreatmentRecordID Then
            ws.Cells(r, 18).Value = "Resolved"
            modAudit.WriteAuditLog "Update", "Treatment_Record", OriginalTreatmentRecordID, _
                "ShortageStatus", "Pending", "Resolved", "PendingNextCard 補扣完成"
            Exit For
        End If
    Next r
End Sub
