Attribute VB_Name = "modValidation"
Option Explicit

Public Sub RequireField(ByVal ValueToCheck As Variant, ByVal MessageText As String)
    If Len(Trim$(CStr(ValueToCheck))) = 0 Then
        Err.Raise vbObjectError + 2201, , MessageText
    End If
End Sub

Public Sub ValidateCardBalance(ByVal RemainingSessions As Double)
    If RemainingSessions < 0 Then
        Err.Raise vbObjectError + 2202, , "套卡餘額不得小於 0。"
    End If
End Sub
