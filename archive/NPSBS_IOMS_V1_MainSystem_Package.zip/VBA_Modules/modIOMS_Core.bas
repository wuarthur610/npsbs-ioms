Attribute VB_Name = "modIOMS_Core"
Option Explicit

Public Function GetCustomerIDByName(ByVal CustomerName As String) As String
    Dim ws As Worksheet, r As Long, lastRow As Long, found As String
    Set ws = ThisWorkbook.Worksheets("Customer_Master")
    lastRow = ws.Cells(ws.Rows.Count, 2).End(xlUp).Row
    For r = 2 To lastRow
        If Trim$(CStr(ws.Cells(r, 2).Value)) = Trim$(CustomerName) Then
            If found <> "" Then Err.Raise vbObjectError + 2001, , "同名客戶超過一筆，請店長確認。"
            found = CStr(ws.Cells(r, 1).Value)
        End If
    Next r
    GetCustomerIDByName = found
End Function

Public Function CalculateSessionCount(ByVal StartTime As Date, ByVal EndTime As Date, _
                                       ByVal AdjustedSessions As Variant) As Double
    If Len(Trim$(CStr(AdjustedSessions))) > 0 Then
        CalculateSessionCount = CDbl(AdjustedSessions)
    Else
        CalculateSessionCount = Round(((EndTime - StartTime) * 1440#) / 40#, 2)
    End If
End Function

Public Function SessionAdjustedFlag(ByVal AdjustedSessions As Variant) As Boolean
    SessionAdjustedFlag = (Len(Trim$(CStr(AdjustedSessions))) > 0)
End Function
