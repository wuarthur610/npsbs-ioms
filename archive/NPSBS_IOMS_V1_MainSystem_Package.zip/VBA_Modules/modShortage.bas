Attribute VB_Name = "modShortage"
Option Explicit

Public Const RES_CHARGE As String = "Charge"
Public Const RES_WAIVED As String = "Waived"
Public Const RES_PENDING As String = "PendingNextCard"

Public Function ValidShortageResolution(ByVal Code As String) As Boolean
    ValidShortageResolution = (Code = RES_CHARGE Or Code = RES_WAIVED Or Code = RES_PENDING)
End Function

Public Sub ResolveShortage(ByVal TreatmentRecordID As String, _
                           ByVal ShortageSessions As Double, _
                           ByVal ResolutionCode As String)
    If ShortageSessions <= 0 Then Exit Sub
    If Not ValidShortageResolution(ResolutionCode) Then
        Err.Raise vbObjectError + 2101, , _
        "請選擇：收取減少堂數費用／直接減免／暫時保留至下次購買再扣堂數。"
    End If
    ' Write resolution and status to Treatment_Record.
    ' Original TreatmentRecord remains unchanged after completion.
End Sub

Public Sub SettlePendingShortage(ByVal OriginalTreatmentRecordID As String, _
                                 ByVal NewCardID As String, _
                                 ByVal Sessions As Double)
    ' Create a NEW Card_Usage_Detail record.
    ' Link it to OriginalTreatmentRecordID.
    ' Never rewrite the original Treatment_Record.
End Sub
