Attribute VB_Name = "modErrorHandler"
Option Explicit

Public Sub IOMSError(ByVal ProcedureName As String, ByVal ErrorNumber As Long, ByVal Description As String)
    MsgBox "NPSBS IOMS 錯誤" & vbCrLf & _
           "程序：" & ProcedureName & vbCrLf & _
           "錯誤：" & ErrorNumber & vbCrLf & Description, vbCritical, "IOMS"
End Sub
