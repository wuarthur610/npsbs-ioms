Attribute VB_Name = "modCardDeduction"
Option Explicit

' Core rule:
' A future-purchased card can never be used to back-deduct an earlier TreatmentDate.

Public Function CardEligibleForTreatment(ByVal TreatmentDate As Date, _
                                          ByVal PurchaseDate As Date, _
                                          ByVal CardStatus As String) As Boolean
    CardEligibleForTreatment = (TreatmentDate >= PurchaseDate And CardStatus = "Active")
End Function

Public Function DeductSessions(ByVal BeforeSessions As Double, _
                               ByVal RequestedSessions As Double, _
                               ByRef UsedSessions As Double, _
                               ByRef ShortageSessions As Double) As Double
    UsedSessions = WorksheetFunction.Min(Application.Max(BeforeSessions, 0), RequestedSessions)
    ShortageSessions = Application.Max(RequestedSessions - UsedSessions, 0)
    DeductSessions = Application.Max(BeforeSessions - UsedSessions, 0)
End Function
