Attribute VB_Name = "modAudit"
Option Explicit

Public Sub WriteAuditLog(ByVal ActionType As String, ByVal TableName As String, _
                         ByVal RecordID As String, ByVal FieldName As String, _
                         ByVal OldValue As String, ByVal NewValue As String, _
                         Optional ByVal Reason As String = "", _
                         Optional ByVal Notes As String = "")
    Dim ws As Worksheet, r As Long
    Set ws = ThisWorkbook.Worksheets("Audit_Log")
    r = ws.Cells(ws.Rows.Count, 1).End(xlUp).Row + 1
    ws.Cells(r, 1).Value = "AUD-" & Format(Now, "yyyymmddhhmmss") & "-" & r
    ws.Cells(r, 2).Value = Now
    ws.Cells(r, 3).Value = Environ$("Username")
    ws.Cells(r, 4).Value = ActionType
    ws.Cells(r, 5).Value = TableName
    ws.Cells(r, 6).Value = RecordID
    ws.Cells(r, 7).Value = FieldName
    ws.Cells(r, 8).Value = OldValue
    ws.Cells(r, 9).Value = NewValue
    ws.Cells(r, 10).Value = Reason
    ws.Cells(r, 11).Value = Notes
End Sub
