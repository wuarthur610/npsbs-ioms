Attribute VB_Name = "modCard"
Option Explicit

' 對應 M5_VBA_Map: modCard — Card selection/deduction
' Card_Master 欄位: A CardID | B CustomerID | C PurchaseDate | D PurchaseAmount |
'                   E OriginalSessions | F UsedSessions | G RemainingSessions |
'                   H PaymentMethod | I CardStatus | J Notes

' 規則（M5_03_Field_Map / README）：只找 TreatmentDate 當日已生效（PurchaseDate <= TreatmentDate）
' 且 CardStatus = "Active"、RemainingSessions > 0 的卡；未來才生效的卡絕不可回溯扣堂。
' 同一客戶若有多張符合資格的卡，優先使用 PurchaseDate 最早的（先買先扣）。
Public Function FindUsableCard(ByVal CustomerID As String, ByVal TreatmentDate As Date) As String
    Dim ws As Worksheet, r As Long, lastRow As Long
    Dim bestCardID As String, bestDate As Date, found As Boolean

    Set ws = ThisWorkbook.Worksheets("Card_Master")
    lastRow = ws.Cells(ws.Rows.Count, 1).End(xlUp).Row
    found = False

    For r = 2 To lastRow
        If CStr(ws.Cells(r, 2).Value) = CustomerID Then
            Dim purchaseDate As Date, cardStatus As String, remaining As Double
            If IsDate(ws.Cells(r, 3).Value) Then
                purchaseDate = CDate(ws.Cells(r, 3).Value)
                cardStatus = CStr(ws.Cells(r, 9).Value)
                remaining = 0
                If IsNumeric(ws.Cells(r, 7).Value) Then remaining = CDbl(ws.Cells(r, 7).Value)

                If modCardDeduction.CardEligibleForTreatment(TreatmentDate, purchaseDate, cardStatus) _
                   And remaining > 0 Then
                    If Not found Or purchaseDate < bestDate Then
                        bestCardID = CStr(ws.Cells(r, 1).Value)
                        bestDate = purchaseDate
                        found = True
                    End If
                End If
            End If
        End If
    Next r

    If found Then
        FindUsableCard = bestCardID
    Else
        FindUsableCard = ""
    End If
End Function

' 依 CardID 讀取目前剩餘堂數（給 modTreatment 計算 BeforeSessions 用）
Public Function GetCardRemainingSessions(ByVal CardID As String) As Double
    Dim r As Long
    r = FindCardRow(CardID)
    If r = 0 Then
        GetCardRemainingSessions = 0
    Else
        GetCardRemainingSessions = ThisWorkbook.Worksheets("Card_Master").Cells(r, 7).Value
    End If
End Function

' 扣堂後回寫 Card_Master 的 UsedSessions / RemainingSessions
Public Sub ApplyDeduction(ByVal CardID As String, ByVal UsedSessions As Double, ByVal AfterSessions As Double)
    Dim ws As Worksheet, r As Long, oldRemaining As Variant
    Set ws = ThisWorkbook.Worksheets("Card_Master")
    r = FindCardRow(CardID)
    If r = 0 Then Err.Raise vbObjectError + 2501, , "找不到 CardID：" & CardID

    oldRemaining = ws.Cells(r, 7).Value
    modValidation.ValidateCardBalance AfterSessions

    ws.Cells(r, 6).Value = ws.Cells(r, 6).Value + UsedSessions   ' UsedSessions 累加
    ws.Cells(r, 7).Value = AfterSessions                         ' RemainingSessions 覆寫為扣堂後餘額

    modAudit.WriteAuditLog "Update", "Card_Master", CardID, "RemainingSessions", _
        CStr(oldRemaining), CStr(AfterSessions), "調理扣堂"
End Sub

Public Function FindCardRow(ByVal CardID As String) As Long
    Dim ws As Worksheet, r As Long, lastRow As Long
    Set ws = ThisWorkbook.Worksheets("Card_Master")
    lastRow = ws.Cells(ws.Rows.Count, 1).End(xlUp).Row
    For r = 2 To lastRow
        If CStr(ws.Cells(r, 1).Value) = CardID Then
            FindCardRow = r
            Exit Function
        End If
    Next r
    FindCardRow = 0
End Function

' 建立新套卡的 CardID（供未來「套卡購買」流程使用；此模組MVP的每日調理流程不會呼叫到）
Public Function GenerateCardID(ByVal PurchaseDate As Date) As String
    GenerateCardID = "C" & Format(PurchaseDate, "yyyymmdd") & Format(Int(Rnd() * 900) + 100, "000")
End Function
