Attribute VB_Name = "modInventory"
Option Explicit

Public Function Variance(ByVal BookQuantity As Double, ByVal ActualQuantity As Double) As Double
    Variance = ActualQuantity - BookQuantity
End Function

Public Sub ValidateVariance(ByVal VarianceQuantity As Double, ByVal Reason As String)
    If VarianceQuantity <> 0 And Len(Trim$(Reason)) = 0 Then
        Err.Raise vbObjectError + 2301, , "盤點有差異時必須選擇差異原因。"
    End If
End Sub
