Attribute VB_Name = "modCustomer"
Option Explicit

' 對應 M5_VBA_Map: modCustomer — Customer lookup/create/update
' Customer_Master 欄位: A CustomerID | B CustomerName | C FirstVisitDate | D Notes | E Status

' 依姓名查 CustomerID；找不到回傳 ""；同名多筆會由 modIOMS_Core 拋出例外請店長確認
Public Function GetCustomerByName(ByVal CustomerName As String) As String
    GetCustomerByName = modIOMS_Core.GetCustomerIDByName(CustomerName)
End Function

' 新增客戶，回傳新產生的 CustomerID，並寫入 Audit_Log
Public Function CreateCustomer(ByVal CustomerName As String, _
                                Optional ByVal Notes As String = "") As String
    Dim ws As Worksheet, r As Long, newID As String
    modValidation.RequireField CustomerName, "客戶姓名為必填。"

    Set ws = ThisWorkbook.Worksheets("Customer_Master")
    r = ws.Cells(ws.Rows.Count, 1).End(xlUp).Row + 1
    newID = "CUST-" & Format(r - 1, "0000")

    ws.Cells(r, 1).Value = newID
    ws.Cells(r, 2).Value = CustomerName
    ws.Cells(r, 3).Value = Date
    ws.Cells(r, 4).Value = Notes
    ws.Cells(r, 5).Value = "Active"

    modAudit.WriteAuditLog "Create", "Customer_Master", newID, "CustomerName", "", CustomerName
    CreateCustomer = newID
End Function

' 將暫時性 CustomerID（如歷史匯入的 TMP-CUST-xxxx）核對後改為正式 CustomerID
' 只更新 Customer_Master 這一列本身的 ID 欄位，並留下 Audit_Log；
' 若要一併更新 Treatment_Record / Card_Master 中的舊 CustomerID，請另外執行一次資料核對批次（M5-04 之後階段）。
Public Sub UpdateCustomerID(ByVal OldCustomerID As String, ByVal NewCustomerID As String)
    Dim ws As Worksheet, r As Long, lastRow As Long

    modValidation.RequireField OldCustomerID, "OldCustomerID 不可為空。"
    modValidation.RequireField NewCustomerID, "NewCustomerID 不可為空。"

    Set ws = ThisWorkbook.Worksheets("Customer_Master")
    lastRow = ws.Cells(ws.Rows.Count, 1).End(xlUp).Row
    For r = 2 To lastRow
        If CStr(ws.Cells(r, 1).Value) = OldCustomerID Then
            ws.Cells(r, 1).Value = NewCustomerID
            modAudit.WriteAuditLog "Update", "Customer_Master", NewCustomerID, _
                "CustomerID", OldCustomerID, NewCustomerID, "客戶ID核對更新"
            Exit Sub
        End If
    Next r
    Err.Raise vbObjectError + 2401, , "找不到 CustomerID：" & OldCustomerID
End Sub
