Attribute VB_Name = "modUI"
Option Explicit

' 開啟每日調理操作視窗（frmDailyTreatment）。
' 可指派給工作表上的按鈕，或直接按 Alt+F8 執行本巨集。
Public Sub ShowDailyTreatmentForm()
    frmDailyTreatment.Show
End Sub
