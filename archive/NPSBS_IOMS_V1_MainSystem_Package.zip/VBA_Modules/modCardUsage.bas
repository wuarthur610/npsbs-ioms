Attribute VB_Name = "modCardUsage"
Option Explicit

' 對應 M5_VBA_Map: modCardUsage — Usage history
' Card_Usage_Detail 欄位: A TreatmentRecordID | B CardID | C UsageDate |
'                         D BeforeSessions | E UsedSessions | F AfterSessions | G Notes | H CreatedAt
'
' 依 M5_03_Field_Map 規則：不建立獨立 CardUsageID，一律用 TreatmentRecordID 關聯。
' CreateUsageDetail 本身即完成「與 Treatment_Record 連結」，因此 Map 中的 LinkTreatmentRecord
' 併入本函式（見下方 LinkTreatmentRecord 說明），避免重複寫入同一筆關聯。

Public Sub CreateUsageDetail(ByVal TreatmentRecordID As String, ByVal CardID As String, _
                              ByVal UsageDate As Date, ByVal BeforeSessions As Double, _
                              ByVal UsedSessions As Double, _
                              Optional ByVal Notes As String = "")
    Dim ws As Worksheet, r As Long, afterSessions As Double

    modValidation.RequireField TreatmentRecordID, "TreatmentRecordID 不可為空。"
    modValidation.RequireField CardID, "CardID 不可為空。"

    afterSessions = Application.Max(BeforeSessions - UsedSessions, 0)
    modValidation.ValidateCardBalance afterSessions

    Set ws = ThisWorkbook.Worksheets("Card_Usage_Detail")
    r = ws.Cells(ws.Rows.Count, 1).End(xlUp).Row + 1

    ws.Cells(r, 1).Value = TreatmentRecordID
    ws.Cells(r, 2).Value = CardID
    ws.Cells(r, 3).Value = UsageDate
    ws.Cells(r, 4).Value = BeforeSessions
    ws.Cells(r, 5).Value = UsedSessions
    ws.Cells(r, 6).Value = afterSessions
    ws.Cells(r, 7).Value = Notes
    ws.Cells(r, 8).Value = Now

    modAudit.WriteAuditLog "Create", "Card_Usage_Detail", TreatmentRecordID, "UsedSessions", _
        "", CStr(UsedSessions), Notes
End Sub

' 保留此函式以對應 M5_VBA_Map 的命名；實際關聯已在 CreateUsageDetail 的
' TreatmentRecordID 欄位完成。此函式作為「日後補扣（PendingNextCard）」時的
' 語意清楚的呼叫入口：查出原始 TreatmentRecordID 對應的所有扣堂明細筆數，供畫面顯示核對用。
Public Function LinkTreatmentRecord(ByVal TreatmentRecordID As String) As Long
    Dim ws As Worksheet, r As Long, lastRow As Long, cnt As Long
    Set ws = ThisWorkbook.Worksheets("Card_Usage_Detail")
    lastRow = ws.Cells(ws.Rows.Count, 1).End(xlUp).Row
    cnt = 0
    For r = 2 To lastRow
        If CStr(ws.Cells(r, 1).Value) = TreatmentRecordID Then cnt = cnt + 1
    Next r
    LinkTreatmentRecord = cnt
End Function
