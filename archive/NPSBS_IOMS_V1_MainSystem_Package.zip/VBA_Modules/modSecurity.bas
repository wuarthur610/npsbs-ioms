Attribute VB_Name = "modSecurity"
Option Explicit

Public Function HasPermission(ByVal RoleName As String, ByVal ActionName As String) As Boolean
    If RoleName = "StoreManager" Then
        HasPermission = True
    ElseIf RoleName = "Therapist" Then
        HasPermission = (ActionName = "CreateTreatment" Or ActionName = "EditTreatmentNotes")
    Else
        HasPermission = False
    End If
End Function
